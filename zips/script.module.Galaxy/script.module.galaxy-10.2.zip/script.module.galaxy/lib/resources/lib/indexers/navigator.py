# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os, base64, sys, urllib2, urlparse
import xbmc, xbmcaddon, xbmcgui, time, webbrowser

from resources.lib.modules import control
from resources.lib.modules import trakt
from resources.lib.modules import cache

sysaddon = sys.argv[0] ; syshandle = int(sys.argv[1])
artPath = control.artPath() ; addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('imdb.user') == '' else True

traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')


class navigator:
    ADDON_ID      = xbmcaddon.Addon().getAddonInfo('id')
    HOMEPATH      = xbmc.translatePath('special://home/')
    ADDONSPATH    = os.path.join(HOMEPATH, 'addons')
    THISADDONPATH = os.path.join(ADDONSPATH, ADDON_ID)
    NEWSFILE      = base64.b64decode(b'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3RoZTEzY2xvd25zL3Jlc291cmNlcy9tYXN0ZXIveG1scy93aGF0c25ldy54bWw=')
    LOCALNEWS     = os.path.join(THISADDONPATH, 'whatsnew.txt')
    
    def root(self): 
        if self.getMenuEnabled('navi.sports') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Free TV[/COLOR][/B]', 'sports', 'DefaultMovies.gif', 'DefaultMovies.gif')   
        self.addDirectoryItem('[B][COLOR ff8037A0]1 Click Movies[/COLOR][/B]', 'kids1', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Movie Collection[/COLOR][/B]', 'collectionsNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Movies[/COLOR][/B]', 'movieNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tv Shows[/COLOR][/B]', 'tvNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Channels[/COLOR][/B]', 'tvNetworks', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if not control.setting('movie.widget') == '0':
            self.addDirectoryItem('[B][COLOR ff8037A0]New Movies[/COLOR][/B]', 'movieWidget', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]New Episodes[/COLOR][/B]', 'tvWidget', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Search[/COLOR][/B]', 'searchNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tools[/COLOR][/B]', 'toolNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')

        downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
        if downloads == True:
            self.addDirectoryItem(32009, 'downloadNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()
	
    
    def getMenuEnabled(self, menu_title):
        is_enabled = control.setting(menu_title).strip()
        if (is_enabled == '' or is_enabled == 'false'): return False
        return True
#######################################################################
# News and Update Code
    def news(self):
            message=self.open_news_url(self.NEWSFILE)
            r = open(self.LOCALNEWS)
            compfile = r.read()       
            if len(message)>1:
                    if compfile == message:pass
                    else:
                            text_file = open(self.LOCALNEWS, "w")
                            text_file.write(message)
                            text_file.close()
                            compfile = message
            self.showText('Status & Information', compfile)
        
    def open_news_url(self, url):
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'klopp')
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            print link
            return link

    def showText(self, heading, text):
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(500)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                retry -= 1
                win.getControl(1).setLabel(heading)
                win.getControl(5).setText(text)
                quit()
                return
            except: pass
#######################################################################
    def kids(self):
        self.addDirectoryItem('Kids Corner', 'kidscorner', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Cartoons', 'tvshows&url=cartoons', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Nickelodeon', 'tvshows&url=nic', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Cartoon Network', 'tvshows&url=cn', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Disney', 'tvshows&url=dis', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('One Click Kids Movies', 'kids1', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Random Kids', 'kids_random', 'DefaultMovies.gif', 'DefaultMovies.gif')
        
        self.endDirectory()

    def iptv(self):
        self.addDirectoryItem('USA Channels', 'iptv_usa', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('UK Channels', 'iptv_uk', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('WORLD Channels', 'iptv_world', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('CCTV', 'iptv_cctv', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32007, 'channels', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Swift Streams', 'swiftNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()
   
    def movies(self, lite=False):
	
        self.addDirectoryItem('[B][COLOR ff8037A0]Documentary[/COLOR][/B]', 'movies&url=spotlight', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cam Movies[/COLOR][/B]', '247movies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]4K UHD (Real-Debrid Needed)[/COLOR][/B]', '4k', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]1 Click Movies[/COLOR][/B]', '1click', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]1 Click Collections[/COLOR][/B]', '1clickcollections', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.twothousand') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Movies with a Twist[/COLOR][/B]', 'movies&url=twothousand', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.sixtys') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]High Fidelity Movies[/COLOR][/B]', 'movies&url=sixtys', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.seventys') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Anime[/COLOR][/B]', 'movies&url=seventys', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.eightys') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Lets Party Movies[/COLOR][/B]', 'movies&url=eightys', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.ninetys') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Kung Fu Movies[/COLOR][/B]', 'movies&url=ninetys', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Stand up Movies[/COLOR][/B]', 'movies&url=galaxy', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.fiftys') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Best Urban Movies[/COLOR][/B]', 'movies&url=urban', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movietrending') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]HD/UHD Movies[/COLOR][/B]', 'movies&url=trending', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.moviepopular') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Popular Kids Movies[/COLOR][/B]', 'movies&url=popular', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movieviews') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]#1 Picked Movies[/COLOR][/B]', 'movies&url=views', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movieboxoffice') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Box Office Hits[/COLOR][/B]', 'movies&url=boxoffice', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movieoscars') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Academy Award Winning Movies[/COLOR][/B]', 'movies&url=oscars', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movietheaters') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Movies in Theater[/COLOR][/B]', 'movies&url=theaters', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.moviewidget') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]latest Movies[/COLOR][/B]', 'movieWidget', 'DefaultMovies.gif', 'DefaultMovies.gif')			
        if self.getMenuEnabled('navi.moviegenre') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Genres[/COLOR][/B]', 'movieGenres', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movieyears') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Years[/COLOR][/B]', 'movieYears', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.moviepersons') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]People[/COLOR][/B]', 'moviePersons', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.movielanguages') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Language[/COLOR][/B]', 'movieLanguages', 'DefaultMovies.gif', 'DefaultMovies.gif')

            if not control.setting('lists.widget') == '0':
                self.addDirectoryItem('[B][COLOR ff8037A0]My Trakt Moives list[/COLOR][/B]', 'mymovieliteNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]People Search[/COLOR][/B]', 'moviePerson', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Search[/COLOR][/B]', 'movieSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()


    def mymovies(self, lite=False):
        self.accountCheck()

        if traktCredentials == True and imdbCredentials == True:
            self.addDirectoryItem(32032, 'movies&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True, context=(32551, 'moviesToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True, context=(32551, 'moviesToLibrary&url=traktwatchlist'))
            self.addDirectoryItem(32034, 'movies&url=imdbwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        elif traktCredentials == True:
            self.addDirectoryItem(32032, 'movies&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True, context=(32551, 'moviesToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True, context=(32551, 'moviesToLibrary&url=traktwatchlist'))

        elif imdbCredentials == True:
            self.addDirectoryItem(32032, 'movies&url=imdbwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)
            self.addDirectoryItem(32033, 'movies&url=imdbwatchlist2', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        if traktCredentials == True:
            self.addDirectoryItem(32035, 'movies&url=traktfeatured', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        elif imdbCredentials == True:
            self.addDirectoryItem(32035, 'movies&url=featured', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        if traktIndicators == True:
            self.addDirectoryItem(32036, 'movies&url=trakthistory', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        self.addDirectoryItem(32039, 'movieUserlists', 'DefaultMovies.gif', 'DefaultMovies.gif')

        if lite == False:
            self.addDirectoryItem(32031, 'movieliteNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32028, 'moviePerson', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32010, 'movieSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()


    def tvshows(self, lite=False):
        self.addDirectoryItem('[B][COLOR ff8037A0]1 click TV Shows[/COLOR][/B]', 'kids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        if self.getMenuEnabled('navi.fiftyss') == True:
            self.addDirectoryItem('[B][COLOR ff8037A0]Dads Cartoons[/COLOR][/B]', 'tvshows&url=fiftyst', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Whodunit?[/COLOR][/B]', 'tvshows&url=sixtyst', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Who has Talent?[/COLOR][/B]', 'tvshows&url=seventyst', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Kids Cartoons[/COLOR][/B]', 'tvshows&url=views', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Vrooom[/COLOR][/B]', 'tvshows&url=eightyst', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]An Apple A Day[/COLOR][/B]', 'tvshows&url=ninetyst', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Across The Pond[/COLOR][/B]', 'tvshows&url=twothousandt', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Bon Appetit[/COLOR][/B]', 'tvshows&url=food', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Howdy Pardner[/COLOR][/B]', 'tvshows&url=active', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]People Watching[/COLOR][/B]', 'tvshows&url=trending', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Genres[/COLOR][/B]', 'tvGenres', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Networks[/COLOR][/B]', 'tvNetworks', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Most Popular[/COLOR][/B]', 'tvshows&url=popular', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Highly Rated[/COLOR][/B]', 'tvshows&url=rating', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Airing Today[/COLOR][/B]', 'tvshows&url=airing', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]New Tv Shows[/COLOR][/B]', 'tvshows&url=premiere', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Latest Episodes[/COLOR][/B]', 'calendar&url=added', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)
            self.addDirectoryItem('[B][COLOR ff8037A0]Calendar[/COLOR][/B]', 'calendars', 'DefaultMovies.giff', 'DefaultMovies.gif')
			
        if lite == False:
            if not control.setting('lists.widget') == '0':
                self.addDirectoryItem('[B][COLOR ff8037A0]My Trakt Tv Shows list[/COLOR][/B]', 'mytvliteNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif.gif')

            self.addDirectoryItem('[B][COLOR ff8037A0]People Search[/COLOR][/B]', 'tvPerson', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem('[B][COLOR ff8037A0]Search[/COLOR][/B]', 'tvSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()


    def mytvshows(self, lite=False):
        self.accountCheck()

        if traktCredentials == True and imdbCredentials == True:
            self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif', context=(32551, 'tvshowsToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', context=(32551, 'tvshowsToLibrary&url=traktwatchlist'))
            self.addDirectoryItem(32034, 'tvshows&url=imdbwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif')

        elif traktCredentials == True:
            self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif', context=(32551, 'tvshowsToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif', context=(32551, 'tvshowsToLibrary&url=traktwatchlist'))

        elif imdbCredentials == True:
            self.addDirectoryItem(32032, 'tvshows&url=imdbwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32033, 'tvshows&url=imdbwatchlist2', 'DefaultMovies.gif', 'DefaultMovies.gif')

        if traktCredentials == True:
            self.addDirectoryItem(32035, 'tvshows&url=traktfeatured', 'DefaultMovies.gif', 'DefaultMovies.gif')

        elif imdbCredentials == True:
            self.addDirectoryItem(32035, 'tvshows&url=trending', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        if traktIndicators == True:
            self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)
            self.addDirectoryItem(32037, 'calendar&url=progress', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)
            self.addDirectoryItem(32038, 'calendar&url=mycalendar', 'DefaultMovies.gif', 'DefaultMovies.gif', queue=True)

        self.addDirectoryItem(32040, 'tvUserlists', 'DefaultMovies.gif', 'DefaultMovies.gif')

        if traktCredentials == True:
            self.addDirectoryItem(32041, 'episodeUserlists', 'DefaultMovies.gif', 'DefaultMovies.gif')

        if lite == False:
            self.addDirectoryItem(32031, 'tvliteNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32028, 'tvPerson', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32010, 'tvSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()

    def tools(self):
        self.addDirectoryItem(32043, 'openSettings&query=0.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32044, 'openSettings&query=7.1', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32628, 'openSettings&query=1.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32045, 'openSettings&query=2.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32046, 'openSettings&query=10.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32047, 'openSettings&query=4.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32556, 'libraryNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32048, 'openSettings&query=9.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32049, 'viewsNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('Cache Functions', 'cfNavigator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32073, 'authTrakt', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32609, 'urlResolver', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.endDirectory()

    def cf(self):
        self.addDirectoryItem(32050, 'clearSources', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32604, 'clearCacheSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32052, 'clearCache', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32614, 'clearMetaCache', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32613, 'clearAllCache', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()

    def library(self):
        self.addDirectoryItem(32557, 'openSettings&query=5.0', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32558, 'updateLibrary&query=tool', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32559, control.setting('library.movie'), 'DefaultMovies.gif', 'DefaultMovies.gif', isAction=False)
        self.addDirectoryItem(32560, control.setting('library.tv'), 'DefaultMovies.gif', 'DefaultMovies.gif', isAction=False)

        if trakt.getTraktCredentialsInfo():
            self.addDirectoryItem(32561, 'moviesToLibrary&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32562, 'moviesToLibrary&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32563, 'tvshowsToLibrary&url=traktcollection', 'DefaultMovies.gif', 'DefaultMovies.gif')
            self.addDirectoryItem(32564, 'tvshowsToLibrary&url=traktwatchlist', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()

    def downloads(self):
        movie_downloads = control.setting('movie.download.path')
        tv_downloads = control.setting('tv.download.path')

        if len(control.listDir(movie_downloads)[0]) > 0:
            self.addDirectoryItem(32001, movie_downloads, 'DefaultMovies.gif', 'DefaultMovies.gif', isAction=False)
        if len(control.listDir(tv_downloads)[0]) > 0:
            self.addDirectoryItem(32002, tv_downloads, 'DefaultMovies.gif', 'DefaultMovies.gif', isAction=False)

        self.endDirectory()


    def search(self):
        self.addDirectoryItem(32001, 'movieSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32002, 'tvSearch', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32029, 'moviePerson', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem(32030, 'tvPerson', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()

    def views(self):
        try:
            control.idle()

            items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'), (control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]

            select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))

            if select == -1: return

            content = items[select][1]

            title = control.lang(32059).encode('utf-8')
            url = '%s?action=addView&content=%s' % (sys.argv[0], content)

            poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()

            item = control.item(label=title)
            item.setInfo(type='Video', infoLabels = {'title': title})
            item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': banner})
            item.setProperty('Fanart_Image', fanart)

            control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
            control.content(int(sys.argv[1]), content)
            control.directory(int(sys.argv[1]), cacheToDisc=True)

            from resources.lib.modules import views
            views.setView(content, {})
        except:
            return


    def accountCheck(self):
        if traktCredentials == False and imdbCredentials == False:
            control.idle()
            control.infoDialog(control.lang(32042).encode('utf-8'), sound=True, icon='WARNING')
            sys.exit()


    def infoCheck(self, version):
        try:
            control.infoDialog('', control.lang(32074).encode('utf-8'), time=5000, sound=False)
            return '1'
        except:
            return '1'


    def clearCache(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheMeta(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_meta()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheProviders(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_providers()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheSearch(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_search()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheAll(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_all()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True):
        try: name = control.lang(name).encode('utf-8')
        except: pass
        url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
        thumb = os.path.join(artPath, thumb) if not artPath == None else icon
        cm = []
        if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
        if not context == None: cm.append((control.lang(context[0]).encode('utf-8'), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
        item = control.item(label=name)
        item.addContextMenuItems(cm)
        item.setArt({'icon': thumb, 'thumb': thumb})
        if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
        
    def collections(self, lite=False):
        self.addDirectoryItem('[B][COLOR ff8037A0]Actor Collection[/COLOR][/B]', 'collectionActors', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Movie Collection[/COLOR][/B]', 'collectionBoxset', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Car Movie Collections[/COLOR][/B]', 'collections&url=carmovies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Christmas Collection[/COLOR][/B]', 'collections&url=xmasmovies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]DC Comics Collection[/COLOR][/B]', 'collections&url=dcmovies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kids Collections[/COLOR][/B]', 'collectionKids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Marvel Collection[/COLOR][/B]', 'collections&url=marvelmovies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Superhero Collections[/COLOR][/B]', 'collectionSuperhero', 'DefaultMovies.gif', 'DefaultMovies.gif')
        
        self.endDirectory()

    def collectionActors(self):
        self.addDirectoryItem('[B][COLOR ff8037A0]Adam Sandler[/COLOR][/B]', 'collections&url=adamsandler', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Al Pacino[/COLOR][/B]', 'collections&url=alpacino', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Alan Rickman[/COLOR][/B]', 'collections&url=alanrickman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Anthony Hopkins[/COLOR][/B]', 'collections&url=anthonyhopkins', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Angelina Jolie[/COLOR][/B]', 'collections&url=angelinajolie', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Arnold Schwarzenegger[/COLOR][/B]', 'collections&url=arnoldschwarzenegger', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Charlize Theron[/COLOR][/B]', 'collections&url=charlizetheron', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Clint Eastwood[/COLOR][/B]', 'collections&url=clinteastwood', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Demi Moore[/COLOR][/B]', 'collections&url=demimoore', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Denzel Washington[/COLOR][/B]', 'collections&url=denzelwashington', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Eddie Murphy[/COLOR][/B]', 'collections&url=eddiemurphy', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Elvis Presley[/COLOR][/B]', 'collections&url=elvispresley', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Gene Wilder[/COLOR][/B]', 'collections&url=genewilder', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Gerard Butler[/COLOR][/B]', 'collections&url=gerardbutler', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Goldie Hawn[/COLOR][/B]', 'collections&url=goldiehawn', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jason Statham[/COLOR][/B]', 'collections&url=jasonstatham', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jean-Claude Van Damme[/COLOR][/B]', 'collections&url=jeanclaudevandamme', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jeffrey Dean Morgan[/COLOR][/B]', 'collections&url=jeffreydeanmorgan', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]John Travolt[/COLOR][/B]a', 'collections&url=johntravolta', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Johnny Depp[/COLOR][/B]', 'collections&url=johnnydepp', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Julia Roberts[/COLOR][/B]', 'collections&url=juliaroberts', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kevin Costner[/COLOR][/B]', 'collections&url=kevincostner', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Liam Neeson[/COLOR][/B]', 'collections&url=liamneeson', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Mel Gibson[/COLOR][/B]', 'collections&url=melgibson', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Melissa McCarthy[/COLOR][/B]', 'collections&url=melissamccarthy', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Meryl Streep[/COLOR][/B]', 'collections&url=merylstreep', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Michelle Pfeiffer[/COLOR][/B]', 'collections&url=michellepfeiffer', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Nicolas Cage[/COLOR][/B]', 'collections&url=nicolascage', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Nicole Kidman[/COLOR][/B]', 'collections&url=nicolekidman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Paul Newman[/COLOR][/B]', 'collections&url=paulnewman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Reese Witherspoon[/COLOR][/B]', 'collections&url=reesewitherspoon', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Robert De Niro[/COLOR][/B]', 'collections&url=robertdeniro', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Samuel L Jackson[/COLOR][/B]', 'collections&url=samueljackson', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sean Connery[/COLOR][/B]', 'collections&url=seanconnery', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Scarlett Johansson[/COLOR][/B]', 'collections&url=scarlettjohansson', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sharon Stone[/COLOR][/B]', 'collections&url=sharonstone', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sigourney Weaver[/COLOR][/B]', 'collections&url=sigourneyweaver', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Steven Seagal[/COLOR][/B]', 'collections&url=stevenseagal', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tom Hanks[/COLOR][/B]', 'collections&url=tomhanks', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Vin Diesel[/COLOR][/B]', 'collections&url=vindiesel', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Wesley Snipes[/COLOR][/B]', 'collections&url=wesleysnipes', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Will Smith[/COLOR][/B]', 'collections&url=willsmith', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Winona Ryder[/COLOR][/B]', 'collections&url=winonaryder', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()
    

    def collectionBoxset(self):
        self.addDirectoryItem('[B][COLOR ff8037A0]48 Hrs. (1982-1990)[/COLOR][/B]', 'collections&url=fortyeighthours', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ace Ventura (1994-1995)[/COLOR][/B]', 'collections&url=aceventura', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Airplane (1980-1982)[/COLOR][/B]', 'collections&url=airplane', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Airport (1970-1979)[/COLOR][/B]', 'collections&url=airport', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]American Graffiti (1973-1979[/COLOR][/B])', 'collections&url=americangraffiti', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Anaconda (1997-2004)[/COLOR][/B]', 'collections&url=anaconda', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Analyze This (1999-2002)[/COLOR][/B]', 'collections&url=analyzethis', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Anchorman (2004-2013)[/COLOR][/B]', 'collections&url=anchorman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Austin Powers (1997-2002)[/COLOR][/B]', 'collections&url=austinpowers', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Back to the Future (1985-1990)[/COLOR][/B]', 'collections&url=backtothefuture', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Bad Boys (1995-2003)[/COLOR][/B]', 'collections&url=badboys', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Bad Santa (2003-2016)[/COLOR][/B]', 'collections&url=badsanta', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Basic Instinct (1992-2006)[/COLOR][/B]', 'collections&url=basicinstinct', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Beverly Hills Cop (1984-1994)[/COLOR][/B]', 'collections&url=beverlyhillscop', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Big Mommas House (2000-2011)[/COLOR][/B]', 'collections&url=bigmommashouse', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Blues Brothers (1980-1998)[/COLOR][/B]', 'collections&url=bluesbrothers', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Bourne (2002-2016)[/COLOR][/B]', 'collections&url=bourne', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Bruce Almighty (2003-2007)[/COLOR][/B]', 'collections&url=brucealmighty', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Caddyshack (1980-1988)[/COLOR][/B]', 'collections&url=caddyshack', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cheaper by the Dozen (2003-2005)[/COLOR][/B]', 'collections&url=cheaperbythedozen', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cheech and Chong (1978-1984)[/COLOR][/B]', 'collections&url=cheechandchong', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Childs Play (1988-2004)[/COLOR][/B]', 'collections&url=childsplay', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]City Slickers (1991-1994)[/COLOR][/B]', 'collections&url=cityslickers', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Conan (1982-2011)[/COLOR][/B]', 'collections&url=conan', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Crank (2006-2009)[/COLOR][/B]', 'collections&url=crank', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Crocodile Dundee (1986-2001)[/COLOR][/B]', 'collections&url=crodiledunde', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Da Vinci Code (2006-2017)[/COLOR][/B]', 'collections&url=davincicode', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Daddy Day Care (2003-2007)[/COLOR][/B]', 'collections&url=daddydaycare', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Death Wish (1974-1994)[/COLOR][/B]', 'collections&url=deathwish', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Delta Force (1986-1990)[/COLOR][/B]', 'collections&url=deltaforce', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Die Hard (1988-2013)[/COLOR][/B]', 'collections&url=diehard', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Dirty Dancing (1987-2004)[/COLOR][/B]', 'collections&url=dirtydancing', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Dirty Harry (1971-1988)[/COLOR][/B]', 'collections&url=dirtyharry', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Dumb and Dumber (1994-2014)[/COLOR][/B]', 'collections&url=dumbanddumber', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Escape from New York (1981-1996)[/COLOR][/B]', 'collections&url=escapefromnewyork', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Every Which Way But Loose (1978-1980)[/COLOR][/B]', 'collections&url=everywhichwaybutloose', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Exorcist (1973-2005)[/COLOR][/B]', 'collections&url=exorcist', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Expendables (2010-2014)[/COLOR][/B]', 'collections&url=theexpendables', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Fast and the Furious (2001-2017)[/COLOR][/B]', 'collections&url=fastandthefurious', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Father of the Bride (1991-1995)[/COLOR][/B]', 'collections&url=fatherofthebride', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Fletch (1985-1989)[/COLOR][/B]', 'collections&url=fletch', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Friday (1995-2002)[/COLOR][/B]', 'collections&url=friday', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Friday the 13th (1980-2009)[/COLOR][/B]', 'collections&url=fridaythe13th', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Fugitive (1993-1998)[/COLOR][/B]', 'collections&url=fugitive', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]G.I. Joe (2009-2013)[/COLOR][/B]', 'collections&url=gijoe', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Get Shorty (1995-2005)[/COLOR][/B]', 'collections&url=getshorty', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Gettysburg (1993-2003)[/COLOR][/B]', 'collections&url=gettysburg', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ghost Rider (2007-2011)[/COLOR][/B]', 'collections&url=ghostrider', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ghostbusters (1984-2016)[/COLOR][/B]', 'collections&url=ghostbusters', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Gods Not Dead (2014-2016)[/COLOR][/B]', 'collections&url=godsnotdead', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Godfather (1972-1990)[/COLOR][/B]', 'collections&url=godfather', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Godzilla (1956-2016[/COLOR][/B])', 'collections&url=godzilla', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Grown Ups (2010-2013)[/COLOR][/B]', 'collections&url=grownups', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Grumpy Old Men (2010-2013)[/COLOR][/B]', 'collections&url=grumpyoldmen', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Guns of Navarone (1961-1978)[/COLOR][/B]', 'collections&url=gunsofnavarone', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Halloween (1978-2009)[/COLOR][/B]', 'collections&url=halloween', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hangover (2009-2013[/COLOR][/B])', 'collections&url=hangover', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hannibal Lector (1986-2007)[/COLOR][/B]', 'collections&url=hanniballector', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hellraiser (1987-1996)[/COLOR][/B]', 'collections&url=hellraiser', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Honey I Shrunk the Kids (1989-1995)[/COLOR][/B]', 'collections&url=honeyishrunkthekids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Horrible Bosses (2011-2014)[/COLOR][/B]', 'collections&url=horriblebosses', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hostel (2005-2011)[/COLOR][/B]', 'collections&url=hostel', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hot Shots (1991-1996)[/COLOR][/B]', 'collections&url=hotshots', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Independence Day (1996-2016)[/COLOR][/B]', 'collections&url=independenceday', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Indiana Jones (1981-2008)[/COLOR][/B]', 'collections&url=indianajones', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Insidious (2010-2015)[/COLOR][/B]', 'collections&url=insidious', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Iron Eagle (1986-1992)[/COLOR][/B]', 'collections&url=ironeagle', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jack Reacher (2012-2016)[/COLOR][/B]', 'collections&url=jackreacher', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jack Ryan (1990-2014)[/COLOR][/B]', 'collections&url=jackryan', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jackass (2002-2013)[/COLOR][/B]', 'collections&url=jackass', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]James Bond (1963-2015)[/COLOR][/B]', 'collections&url=jamesbond', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jaws (1975-1987)[/COLOR][/B]', 'collections&url=jaws', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jeepers Creepers (2001-2017)[/COLOR][/B]', 'collections&url=jeeperscreepers', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]John Wick (2014-2017)[/COLOR][/B]', 'collections&url=johnwick', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jumanji (1995-2005)[/COLOR][/B]', 'collections&url=jumanji', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jurassic Park (1993-2015)[/COLOR][/B]', 'collections&url=jurassicpark', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kick-Ass (2010-2013)[/COLOR][/B]', 'collections&url=kickass', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kill Bill (2003-2004)[/COLOR][/B]', 'collections&url=killbill', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]King Kong (1933-2016)[/COLOR][/B]', 'collections&url=kingkong', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Lara Croft (2001-2003)[/COLOR][/B]', 'collections&url=laracroft', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Legally Blonde (2001-2003)[/COLOR][/B]', 'collections&url=legallyblonde', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Lethal Weapon (1987-1998)[/COLOR][/B]', 'collections&url=leathalweapon', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Look Whos Talking (1989-1993)[/COLOR][/B]', 'collections&url=lookwhostalking', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Machete (2010-2013)[/COLOR][/B]', 'collections&url=machete', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Magic Mike (2012-2015)[/COLOR][/B]', 'collections&url=magicmike', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Major League (1989-1998)[/COLOR][/B]', 'collections&url=majorleague', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Man from Snowy River (1982-1988)[/COLOR][/B]', 'collections&url=manfromsnowyriver', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Mask (1994-2005)[/COLOR][/B]', 'collections&url=mask', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Matrix (1999-2003)[/COLOR][/B]', 'collections&url=matrix', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Mechanic (2011-2016)[/COLOR][/B]', 'collections&url=themechanic', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Meet the Parents (2000-2010)[/COLOR][/B]', 'collections&url=meettheparents', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Men in Black (1997-2012)[/COLOR][/B]', 'collections&url=meninblack', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Mighty Ducks (1995-1996)[/COLOR][/B]', 'collections&url=mightyducks', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Miss Congeniality (2000-2005)[/COLOR][/B]', 'collections&url=misscongeniality', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Missing in Action (1984-1988)[/COLOR][/B]', 'collections&url=missinginaction', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Mission Impossible (1996-2015)[/COLOR][/B]', 'collections&url=missionimpossible', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Naked Gun (1988-1994)[/COLOR][/B]', 'collections&url=nakedgun', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]National Lampoon (1978-2006)[/COLOR][/B]', 'collections&url=nationallampoon', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]National Lampoons Vacation (1983-2015)[/COLOR][/B]', 'collections&url=nationallampoonsvacation', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]National Treasure (2004-2007)[/COLOR][/B]', 'collections&url=nationaltreasure', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Neighbors (2014-2016)[/COLOR][/B]', 'collections&url=neighbors', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Night at the Museum (2006-2014)[/COLOR][/B]', 'collections&url=nightatthemuseum', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Nightmare on Elm Street (1984-2010)[/COLOR][/B]', 'collections&url=nightmareonelmstreet', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Now You See Me (2013-2016)[/COLOR][/B]', 'collections&url=nowyouseeme', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Nutty Professor (1996-2000[/COLOR][/B])', 'collections&url=nuttyprofessor', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Oceans Eleven (2001-2007)[/COLOR][/B]', 'collections&url=oceanseleven', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Odd Couple (1968-1998)[/COLOR][/B]', 'collections&url=oddcouple', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Oh, God (1977-1984)[/COLOR][/B]', 'collections&url=ohgod', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Olympus Has Fallen (2013-2016)[/COLOR][/B]', 'collections&url=olympushasfallen', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Omen (1976-1981)[/COLOR][/B]', 'collections&url=omen', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Paul Blart Mall Cop (2009-2015[/COLOR][/B])', 'collections&url=paulblart', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Pirates of the Caribbean (2003-2017)[/COLOR][/B]', 'collections&url=piratesofthecaribbean', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Planet of the Apes (1968-2014)[/COLOR][/B]', 'collections&url=planetoftheapes', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Police Academy (1984-1994)[/COLOR][/B]', 'collections&url=policeacademy', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Poltergeist (1982-1988)[/COLOR][/B]', 'collections&url=postergeist', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Porkys (1981-1985)[/COLOR][/B]', 'collections&url=porkys', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Predator (1987-2010)[/COLOR][/B]', 'collections&url=predator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Purge (2013-2016)[/COLOR][/B]', 'collections&url=thepurge', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Rambo (1982-2008)[/COLOR][/B]', 'collections&url=rambo', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]RED (2010-2013)[/COLOR][/B]', 'collections&url=red', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Revenge of the Nerds (1984-1987)[/COLOR][/B]', 'collections&url=revengeofthenerds', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Riddick (2000-2013)[/COLOR][/B]', 'collections&url=riddick', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ride Along (2014-2016)[/COLOR][/B]', 'collections&url=ridealong', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Ring (2002-2017)[/COLOR][/B]', 'collections&url=thering', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]RoboCop (1987-1993)[/COLOR][/B]', 'collections&url=robocop', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Rocky (1976-2015)[/COLOR][/B]', 'collections&url=rocky', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Romancing the Stone (1984-1985)[/COLOR][/B]', 'collections&url=romancingthestone', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Rush Hour (1998-2007)[/COLOR][/B]', 'collections&url=rushhour', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Santa Clause (1994-2006)[/COLOR][/B]', 'collections&url=santaclause', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Saw (2004-2010)[/COLOR][/B]', 'collections&url=saw', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sex and the City (2008-2010)[/COLOR][/B]', 'collections&url=sexandthecity', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Shaft (1971-2000)[/COLOR][/B]', 'collections&url=shaft', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Shanghai Noon (2000-2003)[/COLOR][/B]', 'collections&url=shanghainoon', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sin City (2005-2014)[/COLOR][/B]', 'collections&url=sincity', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sinister (2012-2015)[/COLOR][/B]', 'collections&url=sinister', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sister Act (1995-1993)[/COLOR][/B]', 'collections&url=sisteract', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Smokey and the Bandit (1977-1986)[/COLOR][/B]', 'collections&url=smokeyandthebandit', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Speed (1994-1997)[/COLOR][/B]', 'collections&url=speed', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Stakeout (1987-1993)[/COLOR][/B]', 'collections&url=stakeout', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Star Trek (1979-2016)[/COLOR][/B]', 'collections&url=startrek', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Star Wars (1977-2015)[/COLOR][/B]', 'collections&url=starwars', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Sting (1973-1983)[/COLOR][/B]', 'collections&url=thesting', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Taken (2008-2014)[/COLOR][/B]', 'collections&url=taken', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Taxi (1998-2007)[/COLOR][/B]', 'collections&url=taxi', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ted (2012-2015)[/COLOR][/B]', 'collections&url=ted', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Teen Wolf (1985-1987)[/COLOR][/B]', 'collections&url=teenwolf', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Terminator (1984-2015)[/COLOR][/B]', 'collections&url=terminator', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Terms of Endearment (1983-1996)[/COLOR][/B]', 'collections&url=termsofendearment', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Texas Chainsaw Massacre (1974-2013)[/COLOR][/B]', 'collections&url=texaschainsawmassacre', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Thing (1982-2011)[/COLOR][/B]', 'collections&url=thething', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Thomas Crown Affair (1968-1999)[/COLOR][/B]', 'collections&url=thomascrownaffair', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Transporter (2002-2015)[/COLOR][/B]', 'collections&url=transporter', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Under Siege (1992-1995)[/COLOR][/B]', 'collections&url=undersiege', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Universal Soldier (1992-2012)[/COLOR][/B]', 'collections&url=universalsoldier', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Wall Street (1987-2010)[/COLOR][/B]', 'collections&url=wallstreet', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Waynes World (1992-1993)[/COLOR][/B]', 'collections&url=waynesworld', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Weekend at Bernies (1989-1993)[/COLOR][/B]', 'collections&url=weekendatbernies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Whole Nine Yards (2000-2004)[/COLOR][/B]', 'collections&url=wholenineyards', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]X-Files (1998-2008)[/COLOR][/B]', 'collections&url=xfiles', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]xXx (2002-2005)[/COLOR][/B]', 'collections&url=xxx', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Young Guns (1988-1990)[/COLOR][/B]', 'collections&url=youngguns', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Zoolander (2001-2016)[/COLOR][/B]', 'collections&url=zoolander', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Zorro (1998-2005)[/COLOR][/B]', 'collections&url=zorro', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()


    def collectionKids(self):
        self.addDirectoryItem('[B][COLOR ff8037A0]Disney Collection[/COLOR][/B]', 'collections&url=disneymovies', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kids Boxset Collection[/COLOR][/B]', 'collectionBoxsetKids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kids Movie Collection[/COLOR][/B]', 'collections&url=kidsmovies', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()
        

    def collectionBoxsetKids(self):
        self.addDirectoryItem('[B][COLOR ff8037A0]101 Dalmations (1961-2003)[/COLOR][/B]', 'collections&url=onehundredonedalmations', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Addams Family (1991-1998)[/COLOR][/B]', 'collections&url=addamsfamily', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Aladdin (1992-1996)[/COLOR][/B]', 'collections&url=aladdin', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Alvin and the Chipmunks (2007-2015)[/COLOR][/B]', 'collections&url=alvinandthechipmunks', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Atlantis (2001-2003)[/COLOR][/B]', 'collections&url=atlantis', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Babe (1995-1998)[/COLOR][/B]', 'collections&url=babe', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Balto (1995-1998)[/COLOR][/B]', 'collections&url=balto', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Bambi (1942-2006[/COLOR][/B])', 'collections&url=bambi', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Beauty and the Beast (1991-2017[/COLOR][/B])', 'collections&url=beautyandthebeast', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Beethoven (1992-2014)[/COLOR][/B]', 'collections&url=beethoven', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Brother Bear (2003-2006)[/COLOR][/B]', 'collections&url=brotherbear', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cars (2006-2017)[/COLOR][/B]', 'collections&url=cars', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cinderella (1950-2007)[/COLOR][/B]', 'collections&url=cinderella', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Cloudy With a Chance of Meatballs (2009-2013)[/COLOR][/B]', 'collections&url=cloudywithachanceofmeatballs', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Despicable Me (2010-2015)[/COLOR][/B]', 'collections&url=despicableme', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Finding Nemo (2003-2016)[/COLOR][/B]', 'collections&url=findingnemo', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Fox and the Hound (1981-2006)[/COLOR][/B]', 'collections&url=foxandthehound', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Free Willy (1993-2010)[/COLOR][/B]', 'collections&url=freewilly', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ghostbusters (1984-2016)[/COLOR][/B]', 'collections&url=ghostbusters', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Gremlins (1984-2016)[/COLOR][/B]', 'collections&url=gremlins', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Happy Feet (2006-2011)[/COLOR][/B]', 'collections&url=happyfeet', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Harry Potter (2001-2011)[/COLOR][/B]', 'collections&url=harrypotter', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Home Alone (1990-2012)[/COLOR][/B]', 'collections&url=homealone', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Homeward Bound (1993-1996)[/COLOR][/B]', 'collections&url=homewardbound', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Honey, I Shrunk the Kids (1989-1997)[/COLOR][/B]', 'collections&url=honeyishrunkthekids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hotel Transylvania (2012-2015)[/COLOR][/B]', 'collections&url=hoteltransylvania', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]How to Train Your Dragon (2010-2014)[/COLOR][/B]', 'collections&url=howtotrainyourdragon', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hunchback of Notre Dame (1996-2002)[/COLOR][/B]', 'collections&url=hunchbackofnotredame', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Ice Age (2002-2016)[/COLOR][/B]', 'collections&url=iceage', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Jurassic Park (1993-2015)[/COLOR][/B]', 'collections&url=jurassicpark', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Kung Fu Panda (2008-2016)[/COLOR][/B]', 'collections&url=kungfupanda', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Lady and the Tramp (1955-2001)[/COLOR][/B]', 'collections&url=ladyandthetramp', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Lilo and Stitch (2002-2006)[/COLOR][/B]', 'collections&url=liloandstitch', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Madagascar (2005-2014)[/COLOR][/B]', 'collections&url=madagascar', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Monsters Inc (2001-2013)[/COLOR][/B]', 'collections&url=monstersinc', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Mulan (1998-2004)[/COLOR][/B]', 'collections&url=mulan', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Narnia (2005-2010)[/COLOR][/B]', 'collections&url=narnia', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]New Groove (2000-2005)[/COLOR][/B]', 'collections&url=newgroove', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Open Season (2006-2015)[/COLOR][/B]', 'collections&url=openseason', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Planes (2013-2014)[/COLOR][/B]', 'collections&url=planes', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Pocahontas (1995-1998)[/COLOR][/B]', 'collections&url=pocahontas', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Problem Child (1990-1995)[/COLOR][/B]', 'collections&url=problemchild', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Rio (2011-2014)[/COLOR][/B]', 'collections&url=rio', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Sammys Adventures (2010-2012)[/COLOR][/B]', 'collections&url=sammysadventures', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Scooby-Doo (2002-2014)[/COLOR][/B]', 'collections&url=scoobydoo', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Short Circuit (1986-1988)[/COLOR][/B]', 'collections&url=shortcircuit', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]hrek (2001-2011)[/COLOR][/B]', 'collections&url=shrek', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]SpongeBob SquarePants (2004-2017)[/COLOR][/B]', 'collections&url=spongebobsquarepants', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Spy Kids (2001-2011)[/COLOR][/B]', 'collections&url=spykids', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Star Wars (1977-2015)[/COLOR][/B]', 'collections&url=starwars', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Stuart Little (1999-2002)[/COLOR][/B]', 'collections&url=stuartlittle', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tarzan (1999-2016)[/COLOR][/B]', 'collections&url=tarzan', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Teenage Mutant Ninja Turtles (1978-2009)[/COLOR][/B]', 'collections&url=teenagemutantninjaturtles', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Jungle Book (1967-2003)[/COLOR][/B]', 'collections&url=thejunglebook', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Karate Kid (1984-2010)[/COLOR][/B]', 'collections&url=thekaratekid', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Lion King (1994-2016)[/COLOR][/B]', 'collections&url=thelionking', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Little Mermaid (1989-1995)[/COLOR][/B]', 'collections&url=thelittlemermaid', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Neverending Story (1984-1994)[/COLOR][/B]', 'collections&url=theneverendingstory', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]The Smurfs (2011-2013)[/COLOR][/B]', 'collections&url=thesmurfs', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tooth Fairy (2010-2012)[/COLOR][/B]', 'collections&url=toothfairy', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tinker Bell (2008-2014)[/COLOR][/B]', 'collections&url=tinkerbell', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Tom and Jerry (1992-2013)[/COLOR][/B]', 'collections&url=tomandjerry', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Toy Story (1995-2014)[/COLOR][/B]', 'collections&url=toystory', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]VeggieTales (2002-2008)[/COLOR][/B]', 'collections&url=veggietales', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Winnie the Pooh (2000-2005)[/COLOR][/B]', 'collections&url=winniethepooh', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Wizard of Oz (1939-2013)[/COLOR][/B]', 'collections&url=wizardofoz', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()


    def collectionSuperhero(self):
        self.addDirectoryItem('[B][COLOR ff8037A0]Avengers (2008-2017)[/COLOR][/B]', 'collections&url=avengers', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Batman (1989-2016)[/COLOR][/B]', 'collections&url=batman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Captain America (2011-2016)[/COLOR][/B]', 'collections&url=captainamerica', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Dark Knight Trilogy (2005-2013)[/COLOR][/B]', 'collections&url=darkknight', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Fantastic Four (2005-2015)[/COLOR][/B]', 'collections&url=fantasticfour', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Hulk (2003-2008)[/COLOR][/B]', 'collections&url=hulk', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Iron Man (2008-2013)[/COLOR][/B]', 'collections&url=ironman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Spider-Man (2002-2017)[/COLOR][/B]', 'collections&url=spiderman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]Superman (1978-2016)[/COLOR][/B]', 'collections&url=superman', 'DefaultMovies.gif', 'DefaultMovies.gif')
        self.addDirectoryItem('[B][COLOR ff8037A0]X-Men (2000-2016)[/COLOR][/B]', 'collections&url=xmen', 'DefaultMovies.gif', 'DefaultMovies.gif')

        self.endDirectory()
        

    def endDirectory(self):
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)


